import { useAuth } from "@/hooks/use-auth";
import { useUsers } from "@/hooks/use-users";
import { useCreateMatch } from "@/hooks/use-matches";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Loader2, Swords } from "lucide-react";
import { useState } from "react";
import { z } from "zod";

export default function NewMatch() {
  const { user } = useAuth();
  const { data: users, isLoading: isLoadingUsers } = useUsers();
  const createMatch = useCreateMatch();
  const [, setLocation] = useLocation();
  
  const [opponentId, setOpponentId] = useState<string>("");
  const [guestName, setGuestName] = useState<string>("");
  const [guestTeam, setGuestTeam] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleStartMatch = async () => {
    if (!user || (!opponentId && !guestName)) return;
    
    setIsSubmitting(true);
    try {
      const match = await createMatch.mutateAsync({
        player1Id: user.id,
        player2Id: opponentId || undefined,
        player2Name: guestName || undefined,
        player2Team: guestTeam || undefined,
      });
      setLocation(`/match/${match.id}`);
    } catch (error) {
      console.error(error);
      setIsSubmitting(false);
    }
  };

  if (isLoadingUsers) {
    return <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  // Filter out current user from opponents list
  const opponents = users?.filter(u => u.id !== user?.id) || [];

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-500">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold font-display">Start New Match</h1>
        <p className="text-muted-foreground">Select an opponent to begin tracking.</p>
      </div>

      <div className="bg-card border border-border rounded-3xl p-8 space-y-8">
        {/* Player 1 (You) */}
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-muted/30 border border-border/50">
          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center border border-primary/20">
            <span className="font-bold text-primary">P1</span>
          </div>
          <div className="flex-1">
            <p className="text-sm text-muted-foreground">Player 1</p>
            <p className="font-bold text-lg">{user?.firstName} {user?.lastName}</p>
          </div>
          <div className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase">You</div>
        </div>

        <div className="flex justify-center">
          <div className="w-10 h-10 rounded-full bg-background border border-border flex items-center justify-center z-10 -my-5 text-muted-foreground">
            <Swords className="w-5 h-5" />
          </div>
        </div>

        {/* Player 2 Selection */}
        <div className="space-y-6">
          <div className="space-y-4">
            <label className="text-sm font-medium text-muted-foreground ml-1">Select from Network</label>
            {opponents.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {opponents.map((opponent) => (
                  <button
                    key={opponent.id}
                    onClick={() => {
                      setOpponentId(opponent.id);
                      setGuestName("");
                    }}
                    className={`
                      flex items-center gap-3 p-3 rounded-xl border transition-all text-left
                      ${opponentId === opponent.id 
                        ? 'bg-primary/10 border-primary shadow-sm ring-1 ring-primary' 
                        : 'bg-background border-border hover:border-primary/50 hover:bg-muted/50'}
                    `}
                  >
                    <img 
                      src={opponent.profileImageUrl || `https://ui-avatars.com/api/?name=${opponent.firstName}+${opponent.lastName}`} 
                      alt={opponent.firstName || 'User'} 
                      className="w-10 h-10 rounded-full bg-muted object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{opponent.firstName} {opponent.lastName}</p>
                      <p className="text-xs text-muted-foreground truncate">Rank: Amateur</p>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground bg-muted/20 p-4 rounded-xl border border-dashed border-border text-center">
                No other players online yet. Use a guest name below!
              </p>
            )}
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">Or Enter Guest</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Team Name"
                value={guestTeam}
                onChange={(e) => {
                  setGuestTeam(e.target.value);
                  setOpponentId("");
                }}
                className="w-full h-12 px-4 rounded-xl bg-background border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Guest Player Name"
                value={guestName}
                onChange={(e) => {
                  setGuestName(e.target.value);
                  setOpponentId("");
                }}
                className="w-full h-12 px-4 rounded-xl bg-background border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
              />
            </div>
          </div>
        </div>

        <Button 
          className="w-full h-14 text-lg font-bold rounded-xl shadow-lg shadow-primary/20" 
          size="lg"
          disabled={(!opponentId && !guestName) || isSubmitting}
          onClick={handleStartMatch}
        >
          {isSubmitting ? <Loader2 className="w-6 h-6 animate-spin" /> : "Start Match"}
        </Button>
      </div>
    </div>
  );
}
