import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";

export * from "./models/auth";

// === TABLE DEFINITIONS ===
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  player1Id: varchar("player1_id").notNull().references(() => users.id),
  player1Name: text("player1_name"), // Editable name for P1
  player1Team: text("player1_team"), // Team name for P1
  player1Rating: text("player1_rating"), // Rating for P1
  player2Id: varchar("player2_id").references(() => users.id), 
  player2Name: text("player2_name"), // Editable name for P2
  player2Team: text("player2_team"), // Team name for P2
  player2Rating: text("player2_rating"), // Rating for P2
  player1Score: integer("player1_score").default(0).notNull(),
  player2Score: integer("player2_score").default(0).notNull(),
  currentBreakerId: varchar("current_breaker_id").references(() => users.id), // Who breaks next
  status: text("status", { enum: ["ongoing", "finished"] }).default("ongoing").notNull(),
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
  winnerId: varchar("winner_id").references(() => users.id),
  
  // Match Clock Sync
  elapsedSeconds: integer("elapsed_seconds").default(1800).notNull(), // Start at 30 minutes (1800s)
  isPaused: boolean("is_paused").default(true).notNull(),
  lastActionAt: timestamp("last_action_at").defaultNow(), // For calculating diffs
});

// === RELATIONS ===
export const matchesRelations = relations(matches, ({ one }) => ({
  player1: one(users, {
    fields: [matches.player1Id],
    references: [users.id],
    relationName: "player1Matches",
  }),
  player2: one(users, {
    fields: [matches.player2Id],
    references: [users.id],
    relationName: "player2Matches",
  }),
  winner: one(users, {
    fields: [matches.winnerId],
    references: [users.id],
  }),
  currentBreaker: one(users, {
    fields: [matches.currentBreakerId],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertMatchSchema = createInsertSchema(matches).omit({ 
  id: true, 
  startTime: true, 
  endTime: true,
  lastActionAt: true
}).extend({
  player2Id: z.string().optional().nullable(),
  player2Name: z.string().optional().nullable(),
  player2Team: z.string().optional().nullable(),
});

// === EXPLICIT API CONTRACT TYPES ===
export type Match = typeof matches.$inferSelect;
export type InsertMatch = z.infer<typeof insertMatchSchema>;

// Request types
export type CreateMatchRequest = {
  player1Id: string;
  player2Id: string;
};

export type UpdateMatchRequest = Partial<InsertMatch>;

// Response types
export type MatchResponse = Match & {
  player1?: typeof users.$inferSelect;
  player2?: typeof users.$inferSelect;
};
