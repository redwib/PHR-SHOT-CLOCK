# PHR Match Clock - Pool Match Tracker

## Overview

PHR Match Clock is a real-time pool match tracking application designed for serious pool players. It enables users to track scores, monitor alternating breaks, and manage match timing with precision. The application provides a dashboard for viewing ongoing and historical matches, match creation workflow, and a live match room with score controls, match clock, and shot clock functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side router)
- **State Management**: TanStack Query for server state caching and synchronization
- **Styling**: Tailwind CSS with shadcn/ui component library (Radix UI primitives)
- **Build Tool**: Vite with hot module replacement

The frontend follows a page-based architecture with pages in `client/src/pages/` (Dashboard, Landing, MatchRoom, NewMatch) and reusable components in `client/src/components/`. Match-specific components like ScoreCard, MatchClock, and ShotClock handle the live tracking UI. Custom hooks in `client/src/hooks/` manage authentication, match data fetching, and user operations.

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints under `/api/` prefix
- **Validation**: Zod schemas for request/response validation
- **Shared Types**: API contracts defined in `shared/routes.ts` ensure type safety between frontend and backend

The server uses a storage abstraction pattern (`server/storage.ts`) with a `DatabaseStorage` class implementing the `IStorage` interface. This pattern allows for easy testing and potential implementation swaps.

### Authentication
- **Method**: Replit OpenID Connect (OIDC) authentication
- **Session Management**: PostgreSQL-backed sessions using `connect-pg-simple` with 1-week TTL
- **Protected Routes**: Middleware-based route protection via `isAuthenticated` function

Authentication is handled through `server/replit_integrations/auth/`. The flow uses Passport.js with OIDC strategy, storing user data in the `users` table and sessions in the `sessions` table.

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with Zod schema generation via `drizzle-zod`
- **Migrations**: Drizzle Kit for schema migrations (`drizzle.config.ts`)

Key tables:
- `users`: User accounts with profile information (managed by Replit Auth)
- `sessions`: Authentication sessions with expiration
- `matches`: Pool match records including player references, scores, timing data, breaker tracking, and status

### Build System
- **Development**: Vite dev server proxied through Express backend with HMR
- **Production**: esbuild bundles the server, Vite bundles the client
- **Output**: `dist/` directory with `dist/public/` for static assets

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **connect-pg-simple**: Session storage in PostgreSQL

### Authentication
- **Replit OIDC**: Authentication provider via `ISSUER_URL` (defaults to `https://replit.com/oidc`)
- **Required Environment Variables**: `DATABASE_URL`, `SESSION_SECRET`, `REPL_ID`

### UI Libraries
- **shadcn/ui**: Component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library

### Data Management
- **TanStack Query**: Server state management with 2-second polling for live match updates
- **Zod**: Runtime type validation for API contracts
- **date-fns**: Date formatting and time calculations

### Fonts
- Google Fonts: Outfit (sans), Chakra Petch (display), JetBrains Mono (monospace)